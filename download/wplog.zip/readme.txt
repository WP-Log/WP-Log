=== WPLog ===
Contributors: wplog
Donate link: https://wplog.org/
Tags: wp log, wordpress logging
Requires at least: 4.7
Tested up to: 5.9
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
#1 FREE wordpress logging and WP security audit log!

== Screenshots ==

1. WordPress Log Viewer

== Frequently Asked Questions ==

= Automatic Log Cleanup? =

Yes, WP Log will automatically cleanup logs monthly (every 30 days).

= How-to Install WP Log? =

Simply, download the FREE WP Log plugin zip file and install it onto your website's WP Admin.

== Upgrade Notice ==

= 1.0.0 =
activity log

== Changelog ==

= 1.0.0 (2022-02-21) =
WordPress debug log